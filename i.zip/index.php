<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=320, initial-scale=1">
    <meta charset="utf-8">
<!DOCTYPE html>
<html>
<head>
  <style>
    .card {
      width: 300px;
      height: 390px;
      margin: auto;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(169,224,194,.82);
      padding: 20px;
    }
    
    .avatar {
  width: 50px;
  height: 50px;
  background-color: #dcdcdc;
  border-radius: 50%;
      position: fixed;
  left: 50%;
  top: 7%;
  margin-left: -25px;
  margin-top: -25px;
  z-index: 1;
}

    .name {
      text-align: center;
      margin-top: 40px;
      font-weight: bold;
    }
    
    .button {
      margin-top: 20px;
      text-align: center;
    }
    
    .button button {
      display: block;
      width: 100%;
      padding: 10px 0;
      background-color: #f0f0f0;
      border: none;
      border-radius: 5px;
      transition: background-color 0.3s;
    }

    .button button:hover {
      background-color: #dcdcdc;
    }
    
    /* 点击动画 */
    @keyframes clickAnimation {
      0% { transform: scale(1); }
      50% { transform: scale(1.2); }
      100% { transform: scale(1); }
    }
  </style>
</head>
<body>
  <div class="card">
    <img src="image.png" class="avatar">
    <div class="name">阿雅S32赛季</div>
    <div class="button">
      
<button id="f1" onclick="animate(this)">1.6倍</button>
  
<button id="f2" onclick="animate(this)">1.8倍</button>

<button id="f3" onclick="animate(this)">2.0倍</button>     
      
<button id="f4" onclick="animate(this)">2.3倍</button>     
      
<button id="f5" onclick="animate(this)">2.5倍</button>
 
<button id="f6" onclick="animate(this)">3.0倍</button>
  
<button id="f8" onclick="animate(this)">炸水晶</button>     

<button id="f9" onclick="animate(this)">强登区</button>     

    </div>
  </div>

  <script>
    function animate(button) {
      button.style.animation = "clickAnimation 3s";
      setTimeout(function() {
        button.style.animation = "";
      }, 3000);
    }
    
    
    var f1 = document.getElementById("f1");
f1.addEventListener("click", function() {
  var ranges = h5gg.getRangesList('smoba');
  var start = Number(ranges[0].start);  
  // 计算偏移量
  var offset1 = 0xc512ee8;
  var offset2 = 0x880;
  var offset3 = 0xcf8; 
  // 计算地址
  var address1 = start + offset1;
  var address2 = Number(h5gg.getValue(address1, 'I64')) + offset2;
  var address3 = Number(h5gg.getValue(address2, 'I64')) + offset3;  
  // 设置值
  h5gg.setValue(address3, 1.6, 'F32');
});
    
    
    
       var f2 = document.getElementById("f2");
f2.addEventListener("click", function() {
  var ranges = h5gg.getRangesList('smoba');
  var start = Number(ranges[0].start);  
  // 计算偏移量
  var offset1 = 0xc512ee8;
  var offset2 = 0x880;
  var offset3 = 0xcf8; 
  // 计算地址
  var address1 = start + offset1;
  var address2 = Number(h5gg.getValue(address1, 'I64')) + offset2;
  var address3 = Number(h5gg.getValue(address2, 'I64')) + offset3;  
  // 设置值
  h5gg.setValue(address3, 1.8, 'F32');
});
    
        var f3 = document.getElementById("f3");
f3.addEventListener("click", function() {
  var ranges = h5gg.getRangesList('smoba');
  var start = Number(ranges[0].start);  
  // 计算偏移量
  var offset1 = 0xc512ee8;
  var offset2 = 0x880;
  var offset3 = 0xcf8; 
  // 计算地址
  var address1 = start + offset1;
  var address2 = Number(h5gg.getValue(address1, 'I64')) + offset2;
  var address3 = Number(h5gg.getValue(address2, 'I64')) + offset3;  
  // 设置值
  h5gg.setValue(address3, 2.0, 'F32');
});
    
        var f4 = document.getElementById("f4");
f4.addEventListener("click", function() {
  var ranges = h5gg.getRangesList('smoba');
  var start = Number(ranges[0].start);  
  // 计算偏移量
  var offset1 = 0xc512ee8;
  var offset2 = 0x880;
  var offset3 = 0xcf8; 
  // 计算地址
  var address1 = start + offset1;
  var address2 = Number(h5gg.getValue(address1, 'I64')) + offset2;
  var address3 = Number(h5gg.getValue(address2, 'I64')) + offset3;  
  // 设置值
  h5gg.setValue(address3, 2.3, 'F32');
});
    
        var f5 = document.getElementById("f5");
f5.addEventListener("click", function() {
  var ranges = h5gg.getRangesList('smoba');
  var start = Number(ranges[0].start);  
  // 计算偏移量
  var offset1 = 0xc512ee8;
  var offset2 = 0x880;
  var offset3 = 0xcf8; 
  // 计算地址
  var address1 = start + offset1;
  var address2 = Number(h5gg.getValue(address1, 'I64')) + offset2;
  var address3 = Number(h5gg.getValue(address2, 'I64')) + offset3;  
  // 设置值
  h5gg.setValue(address3, 2.5, 'F32');
});
    
        var f6 = document.getElementById("f6");
f6.addEventListener("click", function() {
  var ranges = h5gg.getRangesList('smoba');
  var start = Number(ranges[0].start);  
  // 计算偏移量
  var offset1 = 0xc512ee8;
  var offset2 = 0x880;
  var offset3 = 0xcf8; 
  // 计算地址
  var address1 = start + offset1;
  var address2 = Number(h5gg.getValue(address1, 'I64')) + offset2;
  var address3 = Number(h5gg.getValue(address2, 'I64')) + offset3;  
  // 设置值
  h5gg.setValue(address3, 3.0, 'F32');
});
    
        var f8 = document.getElementById("f8");
f8.addEventListener("click", function() {
 h5gg.clearResults(); 
    h5gg.searchNumber('21110623327027200', 'I64', '0x0', '0x160000000'); 
h5gg.editAll("21110627548266486", 'I64'); 
    h5gg.clearResults();

});
    
    
    
    
	      var f9 = document.getElementById("f9");
f9.addEventListener("click", function() {
			h5gg.clearResults();
	h5gg.searchNumber('165675026', 'I32', '0x100000000', '0x200000000');
	var count = h5gg.getResultsCount();
 var r = h5gg.getResults(count);
for (var i = 0; i < count; i++) {
	var addr1 = r[i].address;
	 var weishu = /F44$/;
	var pd = weishu.test(addr1);
		if (pd) {
	h5gg.setValue(addr1, 165675025, "I32");
	 alert('修改成功，请注销重新登陆游戏！');
	}
		}
});
    
    
 
	
	
  </script>
</body>
</html>
